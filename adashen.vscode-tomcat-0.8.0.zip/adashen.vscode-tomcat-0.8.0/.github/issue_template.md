<!-- Use Help > Report Issue to prefill these. -->
- VSCode Version:
- OS Version:
- Tomcat Extension Version:

Steps to Reproduce:

1.
2.

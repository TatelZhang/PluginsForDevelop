# Change Log

## 0.3.0
- Added Java Test Runner and Maven Package Explorer to the pack

## 0.2.0
- Update the links for open source

## 0.1.0
- Initial release